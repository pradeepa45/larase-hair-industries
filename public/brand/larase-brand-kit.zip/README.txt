LARASE HAIR INDUSTRIES PRIVATE LIMITED
Official gold seal on #16110F.

larase-mark.png / .svg     circular seal (transparent outside)
larase-mark-1024.png       high-resolution seal
larase-mark-on-field.png   seal on #16110F square
larase-lockup.png / .svg   seal + wordmark on #16110F
